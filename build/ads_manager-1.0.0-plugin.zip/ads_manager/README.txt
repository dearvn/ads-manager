=== ads_manager ===
Contributors: dearvn
Tags:
Donate link:
Stable tag: trunk
Requires at least: 5.2.0
Requires PHP: 7.0.0
Tested up to: 5.2
License: GPLv2
License:
License URI:



== Description ==

Put your long description here.

== Installation ==

1. Goto your wordpress backend
2. Navigate to Plugins > Add new
3. Search for "ads_manager"
4. "Install"

OR 

1. Download the plugin from this site (wordpress.org)
2. Copy the extracted folder into your `wp-content/plugins` folder
3. Activate the "ads_manager" plugin via the plugins admin page

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==


== Upgrade Notice ==

